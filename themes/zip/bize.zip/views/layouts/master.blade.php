<!DOCTYPE html>
<html lang="vi">

<head>
    @include($_lib.'head')

</head>


<body id="page-top" data-spy="scroll" data-target=".navbar">

{!! $html->top->embeds !!}

<!--start main container-->
<div id="main" class="main">
    <div class="main-content-inner">

        <!--start header section-->
        @include($_template.'header')
        <!--end header section-->
        @yield('content')

        
        <!--start footer one section-->
        @include($_template.'footer')
        <!--end footer one section-->


    </div><!--end main content inner-->
</div>
<!--end main container -->


<!---start preloader-->
<div id="preloader">
    <div id="status">
        <div class="biz-preloader"></div>
    </div>
</div>
<!--end preloader-->


<!--=========== all js file link ==============-->
@include($_template.'js')
{!! $html->bottom->embeds !!}

</body>


</html>
