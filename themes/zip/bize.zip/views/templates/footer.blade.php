@php
    $footer = $options->theme->footer;
    if(!$footer) $footer = $helper->crazyArr([]);
@endphp

        <footer class="footer footer-text ptb-40">
            <div class="footer-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            @if ($footer->show_socials)
                                
                            <div class="footer-social-list text-center">
                                <h6>Kết nối chúng tôi trên</h6>
                                <ul class="list-inline">
                                    @foreach (['facebook', 'twitter', 'linkedin', 'youtube'] as $item)
                                        @if ($social = $footer->get($item))
                                            <li><a href="{{$social}}"><i class="fa fa-{{$item}} {{$item}}"></i></a></li>
                                        @endif
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                            <div class="copyright-text text-center">
                                @if ($footer->copyright)
                                    {!! $footer->copyright !!}
                                @else
                                <p>&copy; Copyright {{date('Y')}} <a href="/">{{$siteinfo->site_name}}</a></p>
                                @endif
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>