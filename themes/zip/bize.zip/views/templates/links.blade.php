
    @include($_lib.'css')
    <!--favicon icon-->
    <link rel="icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('icons/favicon.ico')}}" type="image/png" sizes="16x16">
    <link rel="apple-touch-icon" sizes="57x57" href="{{theme_asset('icons/apple-icon-57x57.png')}}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{theme_asset('icons/apple-icon-60x60.png')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{theme_asset('icons/apple-icon-72x72.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{theme_asset('icons/apple-icon-76x76.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{theme_asset('icons/apple-icon-114x114.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{theme_asset('icons/apple-icon-120x120.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{theme_asset('icons/apple-icon-144x144.png')}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{theme_asset('icons/apple-icon-152x152.png')}}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{theme_asset('icons/apple-icon-180x180.png')}}">
    <link rel="icon" type="image/png" sizes="192x192" href="{{theme_asset('icons/android-icon-192x192.png')}}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{theme_asset('icons/favicon-32x32.png')}}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{theme_asset('icons/favicon-96x96.png')}}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{theme_asset('icons/favicon-16x16.png')}}">
    <link rel="manifest" href="{{theme_asset('manifest.json')}}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{theme_asset('icons/ms-icon-144x144.png')}}">
    <meta name="theme-color" content="#ffffff">

    <!-- font-awesome css -->
    <link rel="stylesheet" href="{{theme_asset('css/font-awesome.min.css')}}">

    <!--themify icon-->
    <link rel="stylesheet" href="{{theme_asset('css/themify-icons.css')}}">

    <!-- magnific popup css-->
    <link rel="stylesheet" href="{{theme_asset('css/magnific-popup.css')}}">

    <!--owl carousel -->
    <link href="{{theme_asset('css/owl.theme.default.min.css')}}" rel="stylesheet">
    <link href="{{theme_asset('css/owl.carousel.min.css')}}" rel="stylesheet">

    <!-- bootstrap core css -->
    <link href="{{theme_asset('css/bootstrap.min.css')}}" rel="stylesheet">

    <!-- custom css -->
    <link href="{{theme_asset('css/style.css')}}" rel="stylesheet">

    <!-- responsive css -->
    <link href="{{theme_asset('css/responsive.css')}}" rel="stylesheet">


    <script src="{{theme_asset('js/vendor/modernizr-2.8.1.min.js')}}"></script>
    <!-- HTML5 Shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="{{theme_asset('js/vendor/html5shim.js')}}"></script>
    <script src="{{theme_asset('js/vendor/respond.min.js')}}"></script>
    <![endif]-->
    <style>
        .biz-slider-text {
            background: #ffffffc7;
            padding: 10px 20px;
        }

        #typed-strings span.label-text:before {
            left: 20px;
        }

        .navbar-brand {
            padding: 0 !important;
        }
        .single-team-profile img{
            object-fit: cover;
            height: 600px;
        }
        @media (min-width: 768px) {
            .navbar {
                padding: 0;
            }
            .single-team-profile img{
                object-fit: cover;
                height: 320px;
            }
        }
    </style>