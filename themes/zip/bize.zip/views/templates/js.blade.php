

<!-- main jQuery -->
<script src="{{theme_asset('js/jquery-3.2.1.min.js')}}"></script>

<!-- bootstrap core js -->
<script src="{{theme_asset('js/bootstrap.min.js')}}"></script>

<!-- smoothscroll -->
<script src="{{theme_asset('js/jquery.easeScroll.js')}}"></script>

<!--owl carousel-->
<script src="{{theme_asset('js/owl.carousel.min.js')}}"></script>

<!-- scrolling nav -->
<script src="{{theme_asset('js/jquery.easing.min.js')}}"></script>

<!--image load js-->
<script src="{{theme_asset('js/imagesloaded.pkgd.min.js')}}"></script>

<!--isotop js-->
<script src="{{theme_asset('js/isotope.pkgd.min.js')}}"></script>

<!--fullscreen background video js-->
<script src="{{theme_asset('js/jquery.mb.ytplayer.min.js')}}"></script>

<!--typed js -->
<script src="{{theme_asset('js/typed.js')}}"></script>

<!--magnific popup js-->
<script src="{{theme_asset('js/magnific-popup.min.js')}}"></script>

<script type="text/javascript" src="{{theme_asset('js/lazy/jquery.lazy.min.js')}}"></script>

@include($_lib.'js')


<!-- thiet lập js trc khi chay script -->

@yield('jsinit')

<!-- custom script -->
<script src="{{theme_asset('js/scripts.js')}}"></script>

<!-- js tại view -->
@yield('js')