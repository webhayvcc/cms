
        <div class="testimonial-section ptb-100" style="background: url('{{$data->background?$data->background:theme_asset('img/testimonial-bg.jpg')}}') no-repeat center center / cover">
            <div class="testimonial-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="headingOne text-center white-heading">
                                <h6 class="sub">{{$data->sub_title('Our Lovely Clients')}}</h6>
                                <h2>{{$data->title('We Are Trusted By')}}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="owl-carousel owl-theme client-testimonial white-indicator">
                                
                                @if ($data->list_type == 'data')
                                    @if ($data->item_number > 0 && count($testimonials = $helper->getTestimonials(['@sort' => $data->sort_type, '@limit' => $data->item_number])))
                                        @foreach ($testimonials as $testimonial)
                                            <!--Testimonail Item-->
                                            <div class="item single-testimonial pt-50">
                                                <div class="testimonial-intro">
                                                    <p>{{$testimonial->content}} </p>
                                                </div>
                                                <div class="testimonial-client">
                                                    <img src="{{$testimonial->image}}" alt="{{$testimonial->name}}">
                                                    <div class="testimonial-client-info">
                                                        <h5>{{$testimonial->name}}</h5>
                                                        <a href="{{$testimonial->link?$testimonial->link:'#'}}">{{$testimonial->job}}</a>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        @endforeach
                                    @endif
                                @else
                                <!--Testimonials -->
                                    {!! $html->testimonials->components !!}
                                @endif


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
