@php
    $tabs = [];
    $n = 0;
    for ($i=1; $i < 4; $i++) { 
        if($data->{'tab_'.$i.'_show'}){
            $tabs[] = [
                'title' => $data->{'tab_'.$i.'_title'},
                'id' => 'pricing_tab_'.$i,
                'components' => $html->{'tab_'.$i.'_packages'}->components,
                'class' => (($data->tab_active && $data->tab_active == $i) || (!$data->tab_active && $n == 0)) ? 'active' : ''
            ];
            $n++;
        }
    }

    $layouts = [
        1 => [
            "desc" => 'col-md-4',
            'pricing' => 'col-md-7 col-md-offset-1'
        ],
        2 => [
            "desc" => 'col-md-4',
            'pricing' => 'col-md-8'
        ],
        1 => [
            "desc" => 'col-md-3',
            'pricing' => 'col-md-8 col-md-offset-1'
        ],
        1 => [
            "desc" => 'col-md-3',
            'pricing' => 'col-md-9'
        ]
    ];
    $l = $layouts[ strlen($data->layout) && isset($layouts[$data->layout]) ? $data->layout : 1 ];
@endphp

        <!--start pricing section-->
        <div id="pricing" class="bg-secondary ptb-100">
            <div class="container">
                <div class="row">
                    <div class="{{$l['desc']}}">
                        <div class="headingOne text-left">
                            <h6 class="sub">{{$data->sub_title}}</h6>
                            <h2>{{$data->title}}</h2>
                        </div>
                        <p>{{$data->description}}</p>

                        <ul class="nav nav-pills pricing-tab-list" role="tablist">
                            @foreach ($tabs as $tab)
                            <li class="{{$tab['class']}}">
                                <a href="#{{$tab['id']}}" role="tab" data-toggle="tab" aria-expanded="false">
                                    {{$tab['title']}}
                                </a>
                            </li>
                            
                            @endforeach
                        </ul>
                    </div>

                    <div class="{{$l['pricing']}}">
                        <div class="tab-content tab-space">
                            @foreach ($tabs as $tab)
                            <div class="tab-pane {{$tab['class']}}" id="{{$tab['id']}}">
                                {!! $tab['components'] !!}
                            </div>
    
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end pricing section-->
