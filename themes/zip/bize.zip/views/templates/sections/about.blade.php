@php
    $section_title = null;
    $title = null;
    $image = null;
    $description = null;
    $alt = $siteinfo->site_name;
    if($data->page_id && $page = $helper->getPage(['id' => $data->page_id])) {
        $title = $page->title;
        $description = $page->description;
        $image = $page->getFeatureImage();
        $alt = $page->slug;
    }
    if($data->section_title) $section_title = $data->section_title;
    if($data->title) $title = $data->title;
    if($data->image) $image = $data->image;
    if($data->description) $description = $data->description;
    
@endphp

        <section id="about" class="about-section ptb-100">
            <div class="about-section-wrap">
                <div class="container">
                    <div class="row">
                        <div class="headingOne text-center">
                            <!--<h6 class="sub">Our Short Story</h6>-->
                            <h2>{{$section_title}}</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-40">
                            <div class="biz-story-img">
                                <img src="{{$image}}" alt="{{$alt}}" class="img-responsive">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="biz-success-story-text">
                                <h5>{{$title}}</h5>
                                <div class="biz-story-para">
                                    <p>
                                        {!! $description !!}
                                    </p>
                                </div>
                                <!--<div class="biz-story-count text-center">-->
                                <!--<div class="biz-story-count-item col-sm-6 margin-btm-40">-->
                                <!--<h2 class="biz-story-count-value">20 PJ</h2>-->
                                <!--<h6 class="biz-story-count-text">per Week</h6>-->
                                <!--</div>-->
                                <!--<div class="biz-story-count-item col-sm-6">-->
                                <!--<h2 class="biz-story-count-value">200</h2>-->
                                <!--<h6 class="biz-story-count-text">Concurrent-->
                                <!--reports</h6>-->
                                <!--</div>-->
                                <!--</div>-->
                                <!--</div>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
