
        <section id="team" class="team-section ptb-100">
            <div class="team-section-wrap">
                <div class="container">
                    <div class="row">
                        <div class="headingOne text-center">
                            <h6 class="sub">{{$data->sub_title('We make creative')}}</h6>
                            <h2>{{$data->title('Our Lovely Team')}}</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div id="teamSection" class="owl-carousel owl-theme team-carousel">

                            
                        @if ($data->list_type == 'data')
                            @if ($data->item_number > 0 && count($members = $helper->getTeamMembers(['team_id' => $data->team_id, '@sort' => $data->sort_type, '@limit' => $data->item_number])))
                                @foreach ($members as $member)
                                <div class="item">
                                    <div class="team-single-col">
                                        <div class="single-team-profile">
                                            <img src="{{$member->avatar}}" alt="{{$member->name}}" class="img-responsive">
                                            <div class="team-caption">
                                                <div class="team-meta">
                                                    <strong class="team-name">{{$member->name}}</strong>
                                                    <span class="team-spec">{{$member->job}}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
    
                                @endforeach
                            @endif
                        @else
                            {!! $html->team_members->components !!}
                        @endif

                        </div>
                    </div>
                </div>
            </div>
        </section>
