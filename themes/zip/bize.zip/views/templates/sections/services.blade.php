
        <section id="service" class="about-four-tab biz-solution bg-secondary ptb-100">
            <div class="about-four-tab-wrap">
                <div class="container">
                    <div class="row">
                        <div class="headingOne text-center">
                            @if ($data->sub_title)
                                <h6 class="sub">{{$data->sub_title}}</h6>
                            @endif
                            
                            <h2>{{$data->title}}</h2>
                        </div>
                    </div>
                    <div class="row">
                        {!! $html->services->components !!}
                    </div>
                </div>
            </div>
        </section>

        
