

        <section id="hero-section" class="hero-section" style="background: url('{{$data->background?$data->background:theme_asset('img/best-ways-to-come-up-with-company-goals-feature.jpg')}}') no-repeat center center / cover">
            <div class="biz-slider-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="biz-slider-text">
                                <div id="typed-strings">
                                    <span class="label-text">{{$data->sub_title('Connecting to the future')}}</span>
                                    <h1>{{$data->static_title('We Provide')}} <br><span class="typed"></span></h1>
                                    <p>{{$data->description('Our work is the presentation of our capabilities. Professionally myocardinate
                                    high standards in infrastructures and focused solutions. Completely actualize
                                    multifunctional best practices')}}</p>
                                </div>
                                <div class="hero-action-btn">
                                    <a href="{{$data->button_link('#services')}}" class="biz-btn-solid page-scroll">{{$data->button_text('Our Services')}}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        @if ($data->typed_title && count($type_data = array_map('trim', explode(',', $data->typed_title))))
        <script>
            var type_data = {!! json_encode($type_data) !!};
        </script>    
        @endif
        