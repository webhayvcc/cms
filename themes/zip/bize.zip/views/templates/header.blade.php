<?php
$menu = bize_primary_menu();

// new Menu($main_menu, [
//     'menu_class' => 'nav navbar-nav navbar-right',
//     'link_class' => 'page-scroll'
// ]);
?>


        <header class="header">
            <!--start navbar-->
            <div class="navbar navbar-default navbar-fixed-top">
                <div class="background" style="background: #ffffffe0">


                    <div class="container">
                        <div class="row">
                            <div class="navbar-header page-scroll">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                        data-target="#myNavbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand page-scroll" href="{{route('home')}}">
                                    <img src="{{$siteinfo->logo?$siteinfo->logo:theme_asset('img/logo.png')}}"
                                        style="height: 62px;width: auto;" alt="logo">
                                </a>
                            </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="navbar-collapse collapse" id="myNavbar">
                                {!! $menu !!}
                                {{-- <ul class="nav navbar-nav navbar-right">
                                    <li class="active"><a class="page-scroll" href="#main">Home</a></li>
                                    <li><a class="page-scroll" href="#about">About</a></li>
                                    <li><a class="page-scroll" href="#service">Service</a></li>
                                    <li><a class="page-scroll" href="#work">Work</a></li>
                                    <li><a class="page-scroll" href="#team">Team</a></li>
                                    <li><a class="page-scroll" href="#contact">Contact</a></li>
                                </ul> --}}
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!--end navbar-->

        </header>