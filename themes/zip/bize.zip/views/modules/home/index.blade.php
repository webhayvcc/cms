@extends($_layout.'master')
@include($_lib.'register-meta')
@section('content')
@php
$profile = $helper->getProfile();
$sections = bize_sections();

@endphp

@if ($sections)
@foreach ($sections as $page_id => $page)
    @include($_template.'sections.'.$page['template'], [
        'page_id' => $page_id,
        'data' => $page['data'],
        'profile' => $profile
    ])
@endforeach
@endif

@endsection