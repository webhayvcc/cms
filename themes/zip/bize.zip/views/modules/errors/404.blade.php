@extends($_layout.'master')

@section('title', '404 - Not Found')

@section('content')

        <section class="contact-us-section bg-secondary ptb-100">
            <div class="contact-us-wrap" style="padding: 200px 0 130px 0">
                <div class="container">
                    <div class="row">
                        <div class="headingOne text-center">
                            {{-- <h6 class="sub">Reach Us Quickly</h6> --}}
                            <h2>404 - Page Not Found</h2>
                        </div>
                    </div>
                    <div class="message text-center">
                        <p>Hình như có gì đó sai sai!</p>
                    </div>
                </div>
            </div>
        </section>
@endsection