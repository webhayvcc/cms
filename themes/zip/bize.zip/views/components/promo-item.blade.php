
                        <div class="col-sm-6 col-md-3 mb-20">
                            <div class="feature-promo-one-single">
                                <span class="{{$data->icon}}"></span>
                                <div class="feature-promo-one-single-text">
                                    <h6>{{$data->title}}</h6>
                                    <p>{{$data->description}}</p>
                                </div>
                            </div>
                        </div>