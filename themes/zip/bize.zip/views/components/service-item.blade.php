

<div class="col-sm-4">
    <div class="feature feature-1 boxed boxed--border">
        @if ($data->use_label)
        <span class="label label-{{$data->label_class?$data->label_class:'seccess'}}">
            <i class="{{$data->icon?$data->icon:'fa fa-bold'}}"></i> 
            {{$data->label_text}}
        </span>
            
        @endif
        <h5>{{$data->name}}</h5>
        <p>{{$data->description}}</p>
    </div>
    <!--end feature-->
</div>