

<div class="item">
    <div class="team-single-col">
        <div class="single-team-profile">
            <img src="{{$data->avatar}}" alt="{{$data->name}}" class="img-responsive">
            <div class="team-caption">
                <div class="team-meta">
                    <strong class="team-name">{{$data->name}}</strong>
                    <span class="team-spec">{{$data->job}}</span>
                </div>
            </div>
        </div>
    </div>
</div>
