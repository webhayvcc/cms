
<div class="{{$data->class_name?$data->class_name:'col-md-6'}}">
    <div class="card card-pricing {{$data->active?'card-raised':'card-plain'}}">
        <div class="card-content">
            <h6 class="category">{{$data->name}}</h6>
            <h3 class="card-title">{{$data->price_text}} <small>Đ</small></h3>
            <ul>
                <li>
                    {!! implode('</li><li>', $helper->nl2array($data->description)) !!}
                </li>
            </ul>
            <div class="buy-btn">
                <a href="{{$data->link?$data->link:'#'}}" class="{{$data->active?'biz-btn-solid':'biz-btn-outline'}}">
                    {{$data->btn_text}}
                </a>
            </div>
        </div>
    </div>
</div>