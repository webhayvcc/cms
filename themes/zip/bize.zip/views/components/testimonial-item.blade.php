<div class="item single-testimonial pt-50">
    <div class="testimonial-intro">
        <p>{{$data->content}} </p>
    </div>
    <div class="testimonial-client">
        <img src="{{$data->image}}" alt="{{$data->name}}">
        <div class="testimonial-client-info">
            <h5>{{$data->name}}</h5>
            <a href="{{$data->link?$data->link:'#'}}">{{$data->job}}</a>
        </div>
    </div>
</div>