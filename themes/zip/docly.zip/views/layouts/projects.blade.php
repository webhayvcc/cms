<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


<body data-scroll-animation="true">

    {!! $html->top->embeds !!}

    @include($_template.'preloader')
    @php
        $option = $options->theme->projects;
    @endphp
    <div class="body_wrapper">
        
        @include($_template.'headers.style-1')
        @include($_template.'page-header.project')
        @if ($option->show_breadcrumb)
            
            @include($_template.'breadcrumb')
            
        @endif
        @if ($__env->yieldContent('sub_layout') == 'fullwidth')
            <section class="blog_area sec_pad">
                <div class="container">
                    @yield('content')
                </div>
            </section>
            
        @else
            <section class="blog_area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            @yield('content')
                        </div>
                        <div class="col-lg-4">
                            @include($_template.'sidebars.project')
                        </div>
                    </div>
                </div>
            </section>
            
        @endif
        
        @include($_template.'footers.style-1')
    </div>
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>