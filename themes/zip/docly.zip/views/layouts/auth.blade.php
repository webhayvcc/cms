<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


<body data-scroll-animation="true">

    {!! $html->top->embeds !!}

    @include($_template.'preloader')

    <div class="body_wrapper">
        @yield('content')
        
    </div>
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>