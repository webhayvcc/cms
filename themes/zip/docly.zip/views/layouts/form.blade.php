@php
$header = $options->theme->header;
$forms = $options->theme->auth;

$logo_light = $forms->logo_light?$forms->logo_light:(
    $header->logo_light?$header->logo_light:(
        theme_asset('img/logo-white.png')
    )
);

$logo = $forms->logo?$forms->logo:(
    $header->logo?$header->logo:(
        $siteinfo->logo?$siteinfo->logo:(
            theme_asset('img/logo-white.png')
        )
    )
);
@endphp

<!DOCTYPE html>
<html lang="en">

<head>

    @include($_lib.'meta')
    
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/bootstrap.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/fontawesome-all.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/iofrm-style.css')}}">

    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/iofrm-theme3.css')}}">
    <style>
        .form-content .form-items {
            max-width: 400px;
        
        }
        .form-group + .has-error.error,
        .form-control + .has-error.error{
            position: relative;
            top: -14px;
        }
    </style>
    @if ($logo_light)
        <style>
            
        .website-logo .logo {
            background-image: url({{$logo}});
        }
        </style>
    @endif
    <style>
        @media (max-width: 992px){
            .website-logo .logo {
                background-image: url({{$logo_light}});
            }
        }
    
    </style>
    @yield('css')
    
    
    {!! $html->head->embeds !!}
</head>
<body>
    
    {!! $html->top->embeds !!}


    <div class="form-body">
        <div class="website-logo">
            <a href="{{route('home')}}">
                <div class="logo">
                    <img src="{{$logo}}" class="logo logo-size" alt="{{$siteinfo->site_name}}">
                </div>
            </a>
        </div>
        <div class="row">
            <div class="img-holder">
                <div class="bg"></div>
                <div class="info-holder">
    
                </div>
            </div>
            <div class="form-holder">
                <div class="form-content">
                    <div class="form-items">

                        @yield('content')

    
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{theme_asset('forms/js/email-decode.min.js')}}"></script>    
    <script src="{{theme_asset('forms/js/jquery.min.js')}}"></script>
    <script src="{{theme_asset('forms/js/popper.min.js')}}"></script>
    <script src="{{theme_asset('forms/js/bootstrap.min.js')}}"></script>
    <script src="{{theme_asset('forms/js/main.js')}}"></script>

    <script>
        $('.crazy-form').submit(function(e){
            

            if($(this).prop('submitted')) {
                e.preventDefault();
                return false;
            }

            $(this).prop('submitted', true);
            var submit = $(this).find('[type="submit"]');
            submit.html("Đang xử lý...");
            submit.prop("disabled", true);
        });
    </script>
    @yield('js')
    
    {!! $html->bottom->embeds !!}
</body>

</html>