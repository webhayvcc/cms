<!doctype html>
<html lang="en">
<head>
    @include($_lib.'head')
</head>


<body data-scroll-animation="true">

    {!! $html->top->embeds !!}

    @include($_template.'preloader')

    <div class="body_wrapper">
        @include($_template.'headers.style-1')
        {{-- @include($_template.'breadcrumb') --}}
        @yield('content')
        
        @include($_template.'footers.style-1')
    </div>
    <!-- Optional JavaScript -->
    @include($_template.'js')
</body>



</html>