
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="{{theme_asset('js/jquery-3.2.1.min.js')}}"></script>
    <script>var preloader_texts = {!! json_encode(is_array($pl = get_web_data('preloader_data'))?$pl:[]) !!};</script>
    <script src="{{theme_asset('js/pre-loader.js')}}"> </script>
    <script src="{{theme_asset('assets/bootstrap/js/popper.min.js')}}"></script>
    <script src="{{theme_asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="{{theme_asset('assets/bootstrap/js/bootstrap-select.min.js')}}"></script>
    <script src="{{theme_asset('assets/font-size/js/rv-jquery-fontsize-2.0.3.js')}}"></script>
    <script src="{{theme_asset('assets/slick/slick.min.js')}}"></script>
    <script src="{{theme_asset('js/parallaxie.js')}}"></script>
    <script src="{{theme_asset('js/TweenMax.min.js')}}"></script>
    <script src="{{theme_asset('js/jquery.wavify.js')}}"></script>
    <script src="{{theme_asset('js/anchor.js')}}"></script>
    <script src="{{theme_asset('assets/mailchimp/plugins.js')}}"></script>
    <script src="{{theme_asset('assets/wow/wow.min.js')}}"></script>
    <script src="{{theme_asset('assets/niceselectpicker/jquery.nice-select.min.js')}}"></script>
    <script src="{{theme_asset('assets/mcustomscrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>

    <script src="{{theme_asset('js/magnific-popup.min.js')}}"></script>
     
    <!--owl carousel-->
    <script src="{{theme_asset('js/owl.carousel.min.js')}}"></script>
    <!--image load js-->
    <script src="{{theme_asset('js/imagesloaded.pkgd.min.js')}}"></script>
    
    <!--isotop js-->
    <script src="{{theme_asset('js/isotope.pkgd.min.js')}}"></script>
    
    @include($_lib.'js')

    
    <script src="{{theme_asset('js/main.js')}}"></script>
    <script src="{{theme_asset('js/custom.js')}}"></script>