
<section class="breadcrumb_area breadcrumb_area_four">
    <img class="p_absolute bl_left" src="{{theme_asset('img/v.svg')}}" alt="">
    <img class="p_absolute bl_right" src="{{theme_asset('img/home_one/b_leaf.svg')}}" alt="">
    <img class="p_absolute one wow fadeInRight" src="{{theme_asset('img/home_one/b_man_two.png')}}" alt="">
    <div class="container">
        <div class="breadcrumb_content_two text-center">
            <h2>@yield('title', isset($page_title)?$page_title:'')</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    @if ($breadcrumbs = $helper->getBreadcrumbs())
                        @foreach ($breadcrumbs as $item)
                            <li class="breadcrumb-item {{$loop->last?'active':''}}" @if ($loop->last) aria-current="page" @endif>
                                @if ($loop->last)
                                    {{$item->text}}
                                @elseif($loop->first)
                                    <a href="{{$item->url}}"><i class="fas fa-home"></i> {{$item->text}}</a>
                                @else
                                <a href="{{$item->url}}">{{$item->text}}</a>
                                @endif
                            </li>
                        @endforeach
                    @endif
                
                </ol>
            </nav>
        </div>
    </div>
</section>