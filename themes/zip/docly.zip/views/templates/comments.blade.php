<?php
$commentList = (isset($comments) && is_countable($comments)) ? $comments : [];
$refname = isset($ref)?$ref:null;
$refid = isset($ref_id)?$ref_id:0;
$link = isset($url)?$url:null;
$t = count($commentList);
if($user = $helper->getCurrentAccount()){
    $name = $user->name;
    $email = $user->email;
}else{
    $name = null;
    $email = null;
}
?>
    <div class="comment_inner">
        <h2 class="c_head">{{$t}} Bình luận</h2>
        @if ($t)
            @php
                $render = function($factory, $comments, $level = 0){
                    $html = '';
                    if(count($comments)){
                        $html .= '<ul class="list-unstyled '.($level == 0 ? 'comment_box': 'reply_comment').'">';
                            foreach ($comments as $key => $comment) {
                                $avatar = ($comment->author_id && $author = get_model_data('user', $comment->author_id)) ? get_user_avatar($author->avatar) : asset('images/default/avatar.png');

                                $html .= '<li class="'.($level == 0 ? 'post_comment': '').'">';
                                    $html .= '
                                    <div class="media comment_author">
                                        <img class="img_rounded" src="'.$avatar.'" alt="">
                                        <div class="media-body">
                                            <div class="comment_info">
                                                <h3>'.$comment->author_name.'</h3>
                                                <div class="comment_date">'.$comment->dateFormat('d/m/Y - H:i').'</div>
                                            </div>
                                            <p>'.$comment->htmlMessage().'</p>
                                            
                                            '.($level > 3 ? '': '<a href="javascript:void(0);" class="comment_reply btn-reply-comment" data-id="'.$comment->id.'" data-reply-for="'.htmlentities($comment->author_name).'"><i class="arrow_left"></i>Trả lời</a>').'
                                        </div>
                                    </div>
                                    '.(($comment->publishChildren && count($comment->publishChildren)) ? $factory($factory, $comment->publishChildren, $level+1) : '').
                                '</li>';
                                
                            }
                        $html.='</ul>';
                    }
                    return $html;
                };
            @endphp
            {!! $render($render, $comments) !!}
            
        @endif
    </div>

    <div class="blog_comment_box">
        <h2 class="c_head">Để lại ý kiến</h2>
        <p>Email của bạn sẽ dược bão mật. Những trường có dấu * là bắt buộc </p>
        <form method="post" action="{{route('client.comments.post')}}" data-ajax-url="{{route('client.comments.ajax')}}" class="get_quote_form row {{parse_classname('comment-form')}}">
            @csrf
            <input type="hidden" name="parent_id" id="comment-reply-id" >
            <input type="hidden" name="ref" value="{{$refname}}">
            <input type="hidden" name="ref_id" value="{{$refid}}">
            <div class="col-md-6 form-group">
                <input type="text" id="comment_name" name="author_name" class="form-control inp" value="{{old('author_name', $name)}}" placeholder="Tên *" required>
            </div>
            <div class="col-md-6 form-group">
                <input type="email" id="comment_email" name="author_email" class="form-control inp" value="{{old('author_email', $email)}}" placeholder="Email *">
            </div>
            <div class="col-md-12 form-group">
                <input type="url" id="comment_url" name="author_website" class="form-control inp" value="{{old('author_website')}}" placeholder="Website">
            </div>
            <div class="col-md-12 form-group ">
                <div class="crazy-message-content">
                    <textarea name="message" id="comment" class="comment-message-content message inp form-control " placeholder="Viết nội dung bình luận..." required>{{old('message')}}</textarea>
                </div>
            </div>
            <div class="col-md-12">
                <button class="btn action_btn thm_btn" type="submit">Đăng bình luận</button>
            </div>
        </form>
    </div>