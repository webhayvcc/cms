<div class="open_icon" id="right">
    <i class="arrow_carrot-left"></i>
    <i class="arrow_carrot-right"></i>
</div>
<div class="doc_rightsidebar scroll">
    <select id="mySelect">
        <option data-content="<i class='fab fa-windows'></i> Windows">Windows</option>
        <option data-content="<i class='fab fa-apple'></i> Ios">Ios</option>
        <option data-content="<i class='fab fa-linux'></i> Linux">Linux</option>
    </select>
    <div class="d-flex justify-content-between align-items-center">
        <div id="rvfs-controllers" class="fontsize-controllers group"></div>
        <a href="javascript:window.print()" class="print"><i class="icon_printer"></i></a>
    </div>
    <div class="doc_switch">
        <label for="something" class="tab-btn tab-btns"><i class="icon_lightbulb_alt"></i></label>
        <input type="checkbox" name="something" id="something" class="tab_switcher">
        <label for="something" class="tab-btn"><i class="far fa-moon"></i></label>
    </div>
    @if ($bookmark = get_docly_bookmark())
        <h6>Dấu trang:</h6>
        <nav class="list-unstyled doc_menu" id="navbar-example3">
            @foreach ($bookmark as $key => $text)
            <a href="#{{$key}}" class="nav-link">{{$text}}</a>
            @endforeach
        </nav>
    @endif
    
    
</div>