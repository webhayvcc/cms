<aside class="doc_left_sidebarlist">
    <div class="open_icon" id="left">
        <i class="arrow_carrot-right"></i>
        <i class="arrow_carrot-left"></i>
    </div>
    <div class="scroll">
        {!!
            dockly_menu_sidebar($postSettings->sidebar_menu_id('docsleft'),[
                'class' => 'list-unstyled nav-sidebar'
            ])
        !!}
    </div>
</aside>