<nav class="navbar navbar-expand-lg menu_one" id="sticky">
    <div class="container {{$container_class??''}}">
        <a class="navbar-brand sticky_logo" href="{{route('home')}}">
            <img src="{{$lg1 = $header->logo_light($header->logo($siteinfo->logo(theme_asset('img/logo-w.png'))))}}" srcset="{{$lg1}} 2x" alt="{{$siteinfo->site_name}}">
            <img src="{{$lg2 = $header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" srcset="{{$lg2}} 2x" alt="{{$siteinfo->site_name}}">
        </a>
        <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="menu_toggle">
                <span class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
                <span class="hamburger-cross">
                    <span></span>
                    <span></span>
                </span>
            </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            {!!
                dockly_menu_primary([
                    'class' => 'navbar-nav menu ml-auto'
                ])
            !!}
            @if ($header->nav_1_show_button)
                <a class="nav_btn" href="{{$header->nav_1_button_url}}">{{$header->nav_1_button_text}}</a>
            @endif
            
        </div>

    </div>
</nav>
