<section class="page_breadcrumb">
    <div class="container custom_container">
        <div class="row">
            <div class="col-sm-7 col-md-8 col-lg-9 col-xl-10">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        @if ($breadcrumbs = $helper->getBreadcrumbs())
                            @foreach ($breadcrumbs as $item)
                                <li class="breadcrumb-item {{$loop->last?'active':''}}" @if ($loop->last) aria-current="page" @endif>
                                    @if ($loop->last)
                                        {{$item->text}}
                                    @elseif($loop->first)
                                        <a href="{{$item->url}}"><i class="fas fa-home"></i> {{$item->text}}</a>
                                    @else
                                    <a href="{{$item->url}}">{{$item->text}}</a>
                                    @endif
                                </li>
                            @endforeach
                        @endif
                    
                    </ol>
                </nav>
            </div>
            <div class="col-sm-5 col-md-4 col-lg-3 col-xl-2">
                <a href="#" class="date"><i class="icon_clock_alt"></i>Cập nhật <span class="update-time">{{date('d/m/Y')}}</span></a>
            </div>
        </div>
    </div>
</section>