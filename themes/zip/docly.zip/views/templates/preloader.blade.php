@php
    $preloader = $options->theme->preloader;
    $text = $preloader->text($siteinfo->company("VCC"));
    $lines = docly_to_lines($preloader->description($siteinfo->slogan));
    $desc = $lines?($lines[0]??''):'';
    // add_js_data('preloader_data', $lines);
    set_web_data('preloader_data', $lines);
    
@endphp
    <div id="preloader">
        <div id="ctn-preloader" class="ctn-preloader">
            <div class="round_spinner">
                <div class="spinner"></div>
                <div class="text">
                    <img src="{{$preloader->logo($siteinfo->logo(theme_asset('img/spinner_logo.png')))}}" alt="{{$siteinfo->site_name}}">
                    <h4>{!! $text !!}</h4>
                </div>
            </div>
            <h2 class="head">{{$preloader->title($siteinfo->site_name)}}</h2>
            <p>{{$desc}}</p>
        </div>
    </div>
