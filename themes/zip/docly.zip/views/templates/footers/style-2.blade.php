@php
$socials = $options->theme->socials;
$list = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin'];
$footer = $options->theme->footer;
@endphp
<footer class="simple_footer">
    <img class="leaf_right" src="{{theme_asset('img/home_one/leaf_footter.png')}}" alt="">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-sm-6">
                <p>
                    @if ($footer->copyright)
                        {!! $footer->copyright !!}
                    @else
                        &copy; {{date('Y')}} {{$siteinfo->site_name}}. Giữ toàn quyền
                    @endif
                    
                </p>
            </div>
            <div class="col-sm-6 text-right">
                <ul class="list-unstyled f_social_icon">
                    @foreach ($list as $item)
                        @if ($link = $footer->get($item, $socials->get($item)))
                        <li><a href="{{$link}}"><i class="social_{{$item}}"></i></a></li>
                        @endif
                    @endforeach
                    
                </ul>
            </div>
        </div>
    </div>
</footer>