<div class="blog_related_post">
    <h2 class="c_head">{{isset($title)?$title:'Bài viết liên quan'}}</h2>
    <div class="row">
        
        @foreach ($posts as $post)
        @php
            $post->applyMeta();
            $url = $post->getViewUrl();
            $image = $post->getImage('thumbnail');
            $post_title = $post->title
        @endphp
        <div class="col-lg-4 col-sm-6">
            <div class="blog_grid_post wow fadeInUp" data-wow-delay="0.2s">
                @if ($post->contentType('video_embed') || $post->contentType('video'))
                <div class="video_post">
                    <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                    <a class="popup-youtube video_icon" href="{{$url}}"><i class="arrow_triangle-right"></i></a>
                </div>
                @else
                    <a href="{{$url}}">
                        <img class="post-thumbnail" src="{{$image}}" alt="{{$post_title}}">
                    </a>
                @endif

                <div class="grid_post_content">
                    <div class="post_tag">
                        <a href="{{$url}}">{{$post->timeAgo()}}</a>
                            @if ($post->category)
                            <a class="cat-Docly" href="{{$post->category->getViewUrl()}}">{{$post->category->name}}</a>    
                            @elseif(count($post->tags))
                                @foreach ($post->tags as $tag)
                                    @if ($loop->index < 2)
                                        <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                    @endif
                                @endforeach
                            
                            @endif
                            
                    </div>
                    <a href="{{$url}}">
                        <h4 class="b_title">{{$post->title}}</h4>
                    </a>
                    <p>{{$post->getShortDesc(100)}}</p>
                    
                </div>
            </div>
        </div>

        @endforeach

    </div>
</div>