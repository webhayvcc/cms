

    <link rel="shortcut icon" href="{{$siteinfo->favicon?$siteinfo->favicon:theme_asset('img/favicon.ico')}}" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{theme_asset('assets/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{theme_asset('assets/bootstrap/css/bootstrap-select.min.css')}}">

    <link rel="stylesheet" href="{{theme_asset('assets/slick/slick.css')}}">
    <link rel="stylesheet" href="{{theme_asset('assets/slick/slick-theme.css')}}">
    <!-- icon css-->
    <link rel="stylesheet" href="{{theme_asset('assets/elagent-icon/style.css')}}">
    <link rel="stylesheet" href="{{theme_asset('assets/font-awesome/css/all.css')}}">
    {{-- <link rel="stylesheet" href="{{theme_asset('assets/fontawesome5/all.min.css')}}"> --}}
    
    <link rel="stylesheet" href="{{theme_asset('assets/niceselectpicker/nice-select.css')}}">
    <link rel="stylesheet" href="{{theme_asset('assets/animation/animate.css')}}">
    <link rel="stylesheet" href="{{theme_asset('assets/mcustomscrollbar/jquery.mCustomScrollbar.min.css')}}">
    <link rel="stylesheet" href="{{theme_asset('css/style.css')}}">
    <link rel="stylesheet" href="{{theme_asset('css/responsive.css')}}">
    
    <!-- magnific popup css-->
    <link rel="stylesheet" href="{{theme_asset('css/magnific-popup.css')}}">
    
    <!--owl carousel -->
    <link href="{{theme_asset('css/owl.theme.default.min.css')}}" rel="stylesheet">
    <link href="{{theme_asset('css/owl.carousel.min.css')}}" rel="stylesheet">
    
    <link rel="stylesheet" href="{{theme_asset('css/social.links.min.css')}}">
    <link rel="stylesheet" href="{{theme_asset('css/custom.min.css')}}"> 
    