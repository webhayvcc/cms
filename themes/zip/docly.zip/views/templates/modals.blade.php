<div class="modal fade img_modal" id="exampleModal2" tabindex="-2" role="dialog" aria-hidden="false">
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <i class=" icon_close"></i>
    </button>
    <div class="modal-dialog help_form" role="document">
        <div class="modal-content">
            <div class="shortcode_title">
                <h2>How can we help?</h2>
                <p>A premium WordPress theme with integrated Knowledge Base,<br>providing 24/7 community based support.</p>
            </div>
            <form action="#" class="contact_form">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Subject">
                </div>
                <div class="form-group">
                    <textarea name="Message" id="massage" placeholder="Massage"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn action_btn">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>