@php
    $isNotHomeDoc = isset($category) && $category;
@endphp
@extends($_layout.'documentation')
@if ($isNotHomeDoc)
    @section('sticky_menu', 1)
@endif
@include($_lib.'register-meta')

@section('content')
<article class="documentation_body" id="documentation">
    <div class="shortcode_title">
        <h2>{{$page_title}}</h2>
        <p>{!! $dynamic->description !!}</p>
    </div>
    <div class="row mb-150">
        <div class="col-lg-12">
            <div class="alert alert-warning text-center">
                Không có kết quaả phù hợp
            </div>
        </div>
        
    </div>
    
</article>

<div class="border_bottom"></div>


@if ($isNotHomeDoc)
    {!! $html->home_docs->components !!}
@else
    {!! $html->post_docs->components !!}
@endif


@endsection