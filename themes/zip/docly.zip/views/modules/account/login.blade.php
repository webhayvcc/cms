
@extends($_layout.'form')
@section('title', 'Đăng nhập tài khoản')
{{-- @section('page_type', 'my-account') --}}
@section('css')

@endsection
@section('content')

                    <h3>Đăng nhập</h3>
                    <p>Đăng nhập để tiếp tục</p>
                    <div class="page-links">
                        <a class="active" href="{{route('client.account.login')}}">Đăng nhập</a><a href="{{route('client.account.register')}}">Đăng ký</a>
                    </div>
                    @if ($error = session('error'))
                        
                    <div class="alert alert-warning alert-dismissible fade show with-icon" role="alert">
                        {{$error}}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    @endif
                    <form class="{{parse_classname('form')}}" action="{{route('client.account.post-login')}}" method="POST">
                        @if ($next = old('next', $request->next))
                            <input type="hidden" name="next" value="{{$next}}">
                        @endif
                        @csrf
                        <input class="form-control" type="text" name="username" value="{{old('username')}}" placeholder="Tên đăng nhập hoặc email">

                        <input class="form-control" type="password" name="password" placeholder="Mật khẫu">

                        <input type="checkbox" id="remember-me" name="remember" @if(old('remember')) checked @endif>
                        <label for="remember-me">Nhớ đăng nhập</label>
                        <div class="form-button">
                            <button id="submit" type="submit" class="ibtn">Đăng ký</button> <a href="{{route('client.account.forgot')}}">Gặp vấn đề?</a>
                        </div>
                    </form>
                    <div class="other-links">
                        <span>Hoặc sử dụng tài khoản</span>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-google"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
@endsection
