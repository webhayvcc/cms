@php
    $settings = get_account_setting_configs();
@endphp
@extends($_layout.'master',[
    'page_title' => "Đăng ký dịch vụ", 
    'show_breadcrumb' =>  1,
    'breadcrumb_type' => 2
])
@section('title', "Đăng ký dịch vụ")
@include($_lib.'register-meta')

@section('content')
    <div class="blog-area full-blog left-sidebar full-blog default-padding bg-gray ">
       <div class="container">
           <div class="row">
                <div class="blog-items">
                    <div class="sidebar col-md-4">
                        <aside>
                                    
                            <div class="sidebar-item category">
                                <div class="title">
                                    <h4>Panel</h4>
                                </div>
                                <div class="sidebar-info">
                                    <ul>
                                        @foreach ($settings as $sk => $item)
                                            <li><a class="" href="{{route('client.account.settings', ['tab' => $item->slug])}}">{{$item->title}}</a></li>
                                        @endforeach
                                        <li><a class="" href="{{route('client.account.logout')}}">Thoát</a></li>
                                    </ul>
                                </div>
                            </div>
                        </aside>
                    </div>
                    <div class="blog-content col-md-8">
                        <div class="single-item item">
                            <div class="info">
                                <div class="title">
                                    <h4>
                                        <a href="#">{{$account->formConfig->title}} </a>
                                    </h4>
                                </div>
                                <div class="form-section">
                                    <form method="POST" action="{{route('client.account.settings', ['tab' => $account->formConfig->slug])}}" class="form">
                                        @csrf
                                        @if ($message = session('message'))
                                            <div class="alert alert-success mb-3">
                                                {{$message}}
                                            </div>
                                        @elseif($error = session('error'))
                                            <div class="alert alert-danger mb-3">
                                                {{$error}}
                                            </div>
                                        @endif
                                        @if ($form = $account->form)
                                            <?php
                                                $form->map('addClass', 'form-control');
                                            ?>
                                            @foreach ($form as $input)
                                                <div class="form-group">
                                                    <label for="{{$input->id}}" class="form__label">{{$input->label}}</label>
                                                    {!!$input!!}
                                                    @if ($input->error)
                                                        <div class="error has-error text-danger">{{$input->error}}</div>
                                                    @endif
                                            
                                                </div> 
                                            
                                            @endforeach
                                        @endif
                                        
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-theme border btn-sm">Cập nhật</button>
                                            
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
           </div>
       </div>
    </div>
@endsection
