@extends($_layout.'master')
@section('title', $account->formConfig->title)
@include($_lib.'register-meta')

@section('header_style', 2)

@section('content')
@include($_template.'breadcrumb')

<section class="doc_categories_guide_area sec_pad biz-bg-2">
    <img class="shap wow fadeInUp" src="{{theme_asset('img/home_one/dow_bg_two.png')}}" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 order-2 order-lg-1">
                
                @include($_template.'panel',[
                    'settings' => $account->settings
                ])
            </div>
            <div class="col-lg-9 order-2 order-lg-1">
                <div class="categories_guide_item wow fadeInUp" data-wow-delay="0.2s">
                    <div class="doc_tag_title">
                        <h2>{{$account->formConfig->title}}</h2>
                    </div>
                    <div class="form-section blog_comment_box mt-0 pt-0">
                        <form method="POST" action="{{route('client.account.settings', ['tab' => $account->formConfig->slug])}}" class="get_quote_form">
                            @csrf
                            @if ($message = session('message'))
                                <div class="alert alert-success mb-3">
                                    {{$message}}
                                </div>
                            @elseif($error = session('error'))
                                <div class="alert alert-danger mb-3">
                                    {{$error}}
                                </div>
                            @endif
                            @if ($form = $account->form)
                                <?php
                                    $form->map('addClass', 'form-control');
                                ?>
                                @foreach ($form as $input)
                                    <div class="form-group">
                                        <label for="{{$input->id}}" class="form__label">{{$input->label}}</label>
                                        {!!$input!!}
                                        @if ($input->error)
                                            <div class="error has-error text-danger">{{$input->error}}</div>
                                        @endif
                                
                                    </div> 
                                
                                @endforeach
                            @endif
                            
                            <div class="form-group">
                                <button type="submit" class="btn action_btn thm_btn">Cập nhật</button>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
