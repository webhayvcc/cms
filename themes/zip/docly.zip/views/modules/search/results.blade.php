@extends($_layout.'master')
@section('title', $keywords . ' - Kết quã tìm kiếm')
@section('meta.robots', 'noindex,nofollow')
@section('content')

<section class="breadcrumb_area">
    <img class="p_absolute star" src="{{theme_asset('img/home_one/banner_bg.png')}}" alt="">
    <img class="p_absolute wave_shap_one" src="{{theme_asset('img/blog-classic/shap_01.png')}}" alt="">
    <img class="p_absolute wave_shap_two" src="{{theme_asset('img/blog-classic/shap_02.png')}}" alt="">
    <img class="p_absolute one wow fadeInRight" src="{{theme_asset('img/home_one/b_man_two.png')}}" alt="">
    <img class="p_absolute two wow fadeInUp" data-wow-delay="0.2s" src="{{theme_asset('img/home_one/flower.png')}}" alt="">
    <div class="container custom_container">
        <form action="{{route('client.search')}}" class="banner_search_form banner_search_form_two">
            <div class="input-group">
                <input type="search" class="form-control" name="s" placeholder="Tìm kiếm" value="{{$keywords}}">
                <div class="input-group-append">
                    <select class="custom-select" name="ref" id="inlineFormCustomSelect">
                        @if (count($refs = $helper->getSearchRefOptions($r = strtolower($request->ref))))                
                            @foreach ($refs as $ref => $text)
                            <option value="{{$ref}}" {{$ref == $r ? 'selected': ''}}>{{$text}}</option>
                            
                            @endforeach
                        @endif
                    </select>
                </div>
                <button type="submit"><i class="icon_search"></i></button>
            </div>
        </form>
    </div>
</section>

<section class="blog_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                
                @if (count($results))
                <div class="row">
                    @php
                        $item_class = 'col-sm-6';
                    @endphp
                    @foreach ($results as $result)
                    @php
                        $result->applyMeta();
                        $url = $result->getViewUrl();
                        $image = $result->getImage('thumbnail');
                        $result_title = $result->title
                    @endphp
                    <div class="{{$item_class}}">
                        <div class="blog_grid_post wow fadeInUp">
                            
                                <a href="{{$url}}">
                                    <img class="post-thumbnail" src="{{$image}}" alt="{{$result_title}}">
                                </a>
                            
                            <div class="grid_post_content">
                                <div class="post_tag">
                                    <a href="{{$url}}">{{$result->timeAgo()}}</a>
                                        @if ($result->category)
                                        <a class="green" href="{{$result->category->getViewUrl()}}">{{$result->category->name}}</a>    
                                        @elseif(count($result->tags))
                                            @foreach ($result->tags as $tag)
                                                @if ($loop->index < 2)
                                                    <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                                @endif
                                            @endforeach
                                        
                                        @endif
                                        
                                </div>
                                <a href="{{$url}}">
                                    <h4 class="b_title">{{$result->title}}</h4>
                                </a>
                                <p>{{$result->getShortDesc(100)}}</p>
                                    {{-- <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a> --}}
                                    @if ($result->author)
                                            
                                        <div class="media post_author">
                                            <div class="round_img">
                                                <img src="{{$result->author->getAvatar()}}" alt="">
                                            </div>
                                            <div class="media-body author_text">
                                                <a href="#">
                                                    <h4>{{$result->author->name}}</h4>
                                                </a>
                                            </div>
                                        </div>
                                    
                                    @endif
                            </div>
                        </div>
                    </div>
    
                    @endforeach
        
                    
    
                </div>
                
                {{$results->links($_template.'pagination')}}
            @else
            <div class="alert alert-warning">Không có kết quả phù hợp</div>
            @endif


            </div>
            <div class="col-lg-4">
                @include($_template.'sidebars.post')
            </div>
        </div>
    </div>
</section>


@endsection