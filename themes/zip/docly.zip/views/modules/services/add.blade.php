@php
    $serviceSettings = $options->theme->services;
@endphp
@php
    $settings = get_account_setting_configs();
    $form = $helper->getServiceForm();
@endphp
@extends($_layout.'services',[
    'page_title' => "Đăng ký dịch vụ", 
    'show_breadcrumb' =>  1,
    // 'breadcrumb_type' => 2
])
@section('title', "Đăng ký dịch vụ")
@include($_lib.'register-meta')

@section('content')

<section class="doc_categories_guide_area sec_pad biz-bg-2">
    <img class="shap wow fadeInUp" src="{{theme_asset('img/home_one/dow_bg_two.png')}}" alt="">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 order-2 order-lg-1">
                
                @include($_template.'panel')
            </div>
            <div class="col-lg-9 order-2 order-lg-1">
                <div class="categories_guide_item wow fadeInUp" data-wow-delay="0.2s">
                    <div class="doc_tag_title">
                        <h3>Đăng ký dịch vụ</h3>
                    </div>

                    <div class="form-section blog_comment_box mt-0 pt-0">
                        <form method="POST" action="{{route('client.services.add')}}" class="get_quote_form">
                            @csrf
                            @if ($message = session('message'))
                                <div class="alert alert-success mb-3">
                                    {{$message}}
                                </div>
                            @elseif($error = session('error'))
                                <div class="alert alert-danger mb-3">
                                    {{$error}}
                                </div>
                            @endif
                            @if ($form)
                                <?php
                                    $form->map('addClass', 'form-control');
                                ?>
                                <div class="row">
                                @foreach ($form as $input)
                                @php
                                    if($input->defVal() == null) $input->value = $request->get($input->name);
                                @endphp
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="{{$input->id}}" class="form__label">{{$input->label}}</label>
                                                {!!$input!!}
                                                @if ($input->error)
                                                    <div class="error has-error text-danger">{{$input->error}}</div>
                                                @endif
                                        
                                            </div> 
                                        </div>
                                    
                                    @if ($loop->last || $loop->index % 2 == 1)
                                        @if ($loop->index == 1)
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <strong>Giá gói dịch vụ: </strong>
                                                        <span class="price-amount">0</span> VNĐ
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <strong>Phí duy trì <span class="cycle-unit"></span>: </strong>
                                                        <span class="fee-amount">0</span> VNĐ
                                                    </div>
                                                </div>
                                        @endif
                                    @endif
                                @endforeach
                            </div>
                            @endif
                            
                            <div class="form-group">
                                <button type="submit" class="btn action_btn thm_btn">Thêm dịch vụ</button>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection

@section('js')
    <script>
        var services = {!! json_encode($services) !!};
        var serviceMap = {};
        var type = App.getType(services);
        var sid = "{{$request->get('service_id')}}";
        var pid = "{{$request->get('package_id')}}";
        
        if(type == 'array'){
            for (let i = 0; i < services.length; i++) {
                const service = services[i];
                var d = {
                    id: service.id,
                    name: service.name,
                    description: service.description
                };
                var p = {};
                if(service.packages && service.packages.length){
                    for (let j = 0; j < service.packages.length; j++) {
                        const pack = service.packages[j];
                        p[pack.id] = pack;
                    }
                }
                d.packages = p;
                serviceMap[d.id] = d;
            }
        }

        function renderPackageOptions(service_id){
            $('#package_id').html("");
            if(
                service_id &&
                typeof serviceMap[service_id] != "undefined" && 
                typeof serviceMap[service_id].packages != "undefined"
            ){
                var str = '';
                var packages = serviceMap[service_id].packages;
                console.log(packages);
                for (const key in packages) {
                    if (packages.hasOwnProperty(key)) {
                        const pack = packages[key];
                        str += '<option value="'+pack.id+'" ' + ((service_id == sid && pack.id == pid) ? 'selected':'')+'>' + pack.package_name + '</option>';
                    }
                }
                $('#package_id').html(str);
            }
        }
        
        function getPackage(service_id, package_id){
            if(
                service_id && package_id &&
                typeof serviceMap[service_id] != "undefined" && 
                typeof serviceMap[service_id].packages != "undefined" && 
                typeof serviceMap[service_id].packages[package_id] != "undefined"
            ){
                return serviceMap[service_id].packages[package_id];
            }
            return null;
        }

        function checkPriceAndFee(){
            var service_id = $('#service_id').val();
            var package_id = $('#package_id').val();
            var price = 0;
            var fee = 0;
            var pack = getPackage(
                service_id || sid,
                package_id || pid
            );
            if(pack){
                if(App.isNumber(pack.price)){
                    price = pack.price;
                }
                if(App.isNumber(pack.maintenance_fee)){
                    fee = pack.maintenance_fee;
                }
            }
            $('.price-amount').html(App.number.currency(price))
            $('.fee-amount').html(App.number.currency(fee))
        }
        function changeService(){
            var service_id = $('#service_id').val();
            renderPackageOptions(service_id);
            checkPriceAndFee();
        }
        checkPriceAndFee();
        $(document).on("change", "#service_id", function(e){
            changeService();
            console.log(e);
        })
        $(document).on("change", "#package_id", function(e){
            checkPriceAndFee();
        })
    </script>
@endsection