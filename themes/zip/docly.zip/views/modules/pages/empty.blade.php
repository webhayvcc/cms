@php
    $pageSettings = $options->theme->pages;
    $list_layout = $pageSettings->list_layout;
    $breadcrumb = $pageSettings->show_breadcrumb;
    $list_type = $pageSettings->list_type('grid');
@endphp
@extends($_layout.'pages')
@section('sub_layout',$list_layout)
@include($_lib.'register-meta')

@section('content')
    <div class="alert alert-warning">Không có kết quả phù hợp</div>
@endsection
