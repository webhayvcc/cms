@php
    $pageSettings = $options->theme->pages;
    $list_layout = $pageSettings->list_layout;
    $breadcrumb = $pageSettings->show_breadcrumb;
    $list_type = $pageSettings->list_type('grid');
@endphp
@extends($_layout.'pages')
@section('sub_layout',$list_layout)
@include($_lib.'register-meta')

@section('content')
    @if ($list_type == 'list')
        @if (count($pages))
            @foreach ($pages as $page)
            @php
                $page->applyMeta();
                $url = $page->getViewUrl();
                $image = $page->getImage('770x400');
                $page_title = $page->title;
            @endphp
            <div class="blog_top_post blog_classic_item">
                
                    <a href="{{$url}}">
                        <img class="post-thumbnail" src="{{$image}}" alt="{{$page_title}}">
                    </a>
                
                <div class="b_top_post_content">
                    <div class="post_tag">
                        <a href="{{$url}}">{{$page->timeAgo()}}</a>
                            @if ($page->category)
                            <a class="green" href="{{$page->category->getViewUrl()}}">{{$page->category->name}}</a>    
                            @elseif(count($page->tags))
                                @foreach ($page->tags as $tag)
                                    @if ($loop->index < 2)
                                        <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                    @endif
                                @endforeach
                            
                            @endif
                            
                    </div>
                    <a href="{{$url}}">
                        <h4 class="b_title">{{$page->title}}</h4>
                    </a>
                    <p>{{$page->getShortDesc(150)}}</p>
                    <div class="d-flex justify-content-between p_bottom">
                        <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a>
                        @if ($page->author)
                            
                        <div class="media post_author">
                            <div class="round_img">
                                <img src="{{$page->author->getAvatar()}}" alt="">
                            </div>
                            <div class="media-body author_text">
                                <a href="#">
                                    <h4>{{$page->author->name}}</h4>
                                </a>
                            </div>
                        </div>
                        
                        @endif
                    </div>
                </div>
            </div>
            @endforeach

            {{$pages->links($_template.'pagination')}}

        @else
            <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @else
        @php
            $item_class = $list_layout == 'fullwidth' ? 'col-lg-4 col-sm-6' : 'col-sm-6';
        @endphp
        @if (count($pages))
            <div class="row">

                @foreach ($pages as $page)
                @php
                    $page->applyMeta();
                    $url = $page->getViewUrl();
                    $image = $page->getImage('thumbnail');
                    $page_title = $page->title
                @endphp
                <div class="{{$item_class}}">
                    <div class="blog_grid_post wow fadeInUp">
                        
                            <a href="{{$url}}">
                                <img class="post-thumbnail" src="{{$image}}" alt="{{$page_title}}">
                            </a>
                        
                        <div class="grid_post_content">
                            <div class="post_tag">
                                <a href="{{$url}}">{{$page->timeAgo()}}</a>
                                    @if ($page->category)
                                    <a class="green" href="{{$page->category->getViewUrl()}}">{{$page->category->name}}</a>    
                                    @elseif(count($page->tags))
                                        @foreach ($page->tags as $tag)
                                            @if ($loop->index < 2)
                                                <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                            @endif
                                        @endforeach
                                    
                                    @endif
                                    
                            </div>
                            <a href="{{$url}}">
                                <h4 class="b_title">{{$page->title}}</h4>
                            </a>
                            <p>{{$page->getShortDesc(100)}}</p>
                                {{-- <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a> --}}
                                @if ($page->author)
                                        
                                    <div class="media post_author">
                                        <div class="round_img">
                                            <img src="{{$page->author->getAvatar()}}" alt="">
                                        </div>
                                        <div class="media-body author_text">
                                            <a href="#">
                                                <h4>{{$page->author->name}}</h4>
                                            </a>
                                        </div>
                                    </div>
                                
                                @endif
                        </div>
                    </div>
                </div>

                @endforeach
    
                

            </div>
            
            {{$pages->links($_template.'pagination')}}
        @else
        <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @endif
@endsection