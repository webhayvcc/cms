@php
    $projectSettings = $options->theme->projects;
    $list_layout = $projectSettings->list_layout;
    $breadcrumb = $projectSettings->show_breadcrumb;
    $list_type = $projectSettings->list_type('grid');
@endphp

@extends($_layout.'projects')
@section('sub_layout','sidebar')
@include($_lib.'register-meta')

@php
    $u = $article->getViewUrl();
    $a = preg_match('/[^\{}]\{\$gallery\}[^\}]/i', $article->content);
    $b = false;
@endphp


@if ($gallery = $article->gallery)
    @if (count($gallery))
        @php
            $b = true;
        @endphp
        @section('gallery')
            <div class="post-gallert docly-carousel owl-carousel owl-theme" data-show="1" data-dots="true" data-autoplay="true" data-speed="500" data-nav="true" data-loop="true">
                @foreach ($gallery as $item)
                <div class="item">
                    <img class="img-responsive" src="{{$item->getUrl()}}">
                </div>
                @endforeach
            </div>
        @endsection
    @endif
@endif



@section('content')
        
<div class="blog_single_info">
    <div class="blog_single_item">
        
        @if ($b)
            @if ($a)
                <a href="{{$u}}" class="blog_single_img">
                    <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
                </a>
                <div class="post-content">
                    {!! 
                        str_eval($article->content, [
                            'gallery' => $__env->yieldContent('gallery')
                        ])
                    !!}
                </div>
            @else
                @yield('gallery')
                <div class="post-content">
                    {!! $article->content !!}
                </div>
            @endif
        @else
            <a href="{{$u}}" class="blog_single_img">
                <img src="{{$article->getImage()}}" alt="{{$article->title}}" class="post-thumbnail">
            </a>
            <div class="post-content">
                {!! $article->content !!}
            </div>
        
        @endif
        
    
        @include($_template.'share',[
            'title' => $article->title,
            'link' => $u,
            'description' => $article->getShortDesc(150),
            'image' => $article->getImage('social')
        ])
    </div>
    {{-- <div class="blog_post_author media">
        <div class="author_img">
            <img src="img/blog-single/author.jpg" alt="">
        </div>
        <div class="media-body">
            <h5>Jason Response</h5>
            <p>Loo tomfoolery jolly good bloke chancer chimney pot nice one a, he nicked it mufty Oxford say wind up bits and bobs cheeky bugger, amongst cack bugger Eaton William skive off.!</p>
        </div>
    </div> --}}


    @include($_template.'related', [
        'list_title' => 'Có thể bạn quan tâm',
        'posts' => $article->getRelated(3)
    ])



    @include($_template.'comments',[
        'comments' => $article->publishComments,
        'ref' => $article->type,
        'ref_id' => $article->id,
        'url' => $article->getViewUrl()
    ])

</div>


@endsection

