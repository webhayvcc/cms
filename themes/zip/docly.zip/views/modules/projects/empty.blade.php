@php
    $projectSettings = $options->theme->projects;
    $list_layout = $projectSettings->list_layout;
    $breadcrumb = $projectSettings->show_breadcrumb;
    $list_type = $projectSettings->list_type('grid');
@endphp
@extends($_layout.'projects')
@section('sub_layout',$list_layout)
@include($_lib.'register-meta')

@section('content')
    <div class="alert alert-warning">Không có kết quả phù hợp</div>
@endsection
