@php
    $projectSettings = $options->theme->projects;
    $list_layout = $projectSettings->list_layout;
    $breadcrumb = $projectSettings->show_breadcrumb;
    $list_type = $projectSettings->list_type('grid');
@endphp
@extends($_layout.'projects')
@section('sub_layout',$list_layout)
@include($_lib.'register-meta')

@section('content')
    @if ($list_type == 'list')
        @if (count($projects))
            @foreach ($projects as $project)
            @php
                $project->applyMeta();
                $url = $project->getViewUrl();
                $image = $project->getImage('770x400');
                $project_title = $project->title;
            @endphp
            <div class="blog_top_post blog_classic_item">
                
                    <a href="{{$url}}">
                        <img class="post-thumbnail" src="{{$image}}" alt="{{$project_title}}">
                    </a>
                
                <div class="b_top_post_content">
                    <div class="post_tag">
                        <a href="{{$url}}">{{$project->timeAgo()}}</a>
                            @if ($project->category)
                            <a class="green" href="{{$project->category->getViewUrl()}}">{{$project->category->name}}</a>    
                            @elseif(count($project->tags))
                                @foreach ($project->tags as $tag)
                                    @if ($loop->index < 2)
                                        <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                    @endif
                                @endforeach
                            
                            @endif
                            
                    </div>
                    <a href="{{$url}}">
                        <h4 class="b_title">{{$project->title}}</h4>
                    </a>
                    <p>{{$project->getShortDesc(150)}}</p>
                    <div class="d-flex justify-content-between p_bottom">
                        <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a>
                        @if ($project->author)
                            
                        <div class="media post_author">
                            <div class="round_img">
                                <img src="{{$project->author->getAvatar()}}" alt="">
                            </div>
                            <div class="media-body author_text">
                                <a href="#">
                                    <h4>{{$project->author->name}}</h4>
                                </a>
                            </div>
                        </div>
                        
                        @endif
                    </div>
                </div>
            </div>
            @endforeach

            {{$projects->links($_template.'pagination')}}

        @else
            <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @else
        @php
            $item_class = $list_layout == 'fullwidth' ? 'col-lg-4 col-sm-6' : 'col-sm-6';
        @endphp
        @if (count($projects))
            <div class="row">

                @foreach ($projects as $project)
                @php
                    $project->applyMeta();
                    $url = $project->getViewUrl();
                    $image = $project->getImage('thumbnail');
                    $project_title = $project->title
                @endphp
                <div class="{{$item_class}}">
                    <div class="blog_grid_post wow fadeInUp">
                        
                            <a href="{{$url}}">
                                <img class="post-thumbnail" src="{{$image}}" alt="{{$project_title}}">
                            </a>
                        
                        <div class="grid_post_content">
                            <div class="post_tag">
                                <a href="{{$url}}">{{$project->timeAgo()}}</a>
                                    @if ($project->category)
                                    <a class="green" href="{{$project->category->getViewUrl()}}">{{$project->category->name}}</a>    
                                    @elseif(count($project->tags))
                                        @foreach ($project->tags as $tag)
                                            @if ($loop->index < 2)
                                                <a class="c_blue" href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                                            @endif
                                        @endforeach
                                    
                                    @endif
                                    
                            </div>
                            <a href="{{$url}}">
                                <h4 class="b_title">{{$project->title}}</h4>
                            </a>
                            <p>{{$project->getShortDesc(100)}}</p>
                                {{-- <a href="{{$url}}" class="learn_btn">Chi tiết<i class="arrow_right"></i></a> --}}
                                @if ($project->author)
                                        
                                    <div class="media post_author">
                                        <div class="round_img">
                                            <img src="{{$project->author->getAvatar()}}" alt="">
                                        </div>
                                        <div class="media-body author_text">
                                            <a href="#">
                                                <h4>{{$project->author->name}}</h4>
                                            </a>
                                        </div>
                                    </div>
                                
                                @endif
                        </div>
                    </div>
                </div>

                @endforeach
    
                

            </div>
            
            {{$projects->links($_template.'pagination')}}
        @else
        <div class="alert alert-warning">Không có kết quả phù hợp</div>
        @endif
    @endif
@endsection