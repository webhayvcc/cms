<div class="help_item">
    <a href="{{$data->link}}">
        <h4>{{$data->title}}</h4>
    </a>
    <p>{{$data->description}}</p>
</div>