

            <div class="col-lg-6 col-sm-6">
                <div class="media documentation_item">
                    <div class="icon">
                        <a href="{{$data->link}}">
                            <img src="{{$data->img_icon}}" alt="{{$data->title}}">
                        </a>
                    </div>
                    <div class="media-body">
                        <a href="{{$data->link}}">
                            <h5>{{$data->title}}</h5>
                        </a>
                        <p>{{$data->description}}</p>
                    </div>
                </div>
            </div>