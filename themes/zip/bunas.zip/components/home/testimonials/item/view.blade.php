
<div class="item">
    <div class="thumb">
        <img src="{{$data->image}}" alt="Thumb">
    </div>
    <div class="info">
        <h4>{{$data->name}}</h4>
        <span>{{$data->job}}</span>
        <p>
            {{$data->content}}
        </p>
        
    </div>
</div>
