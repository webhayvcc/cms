<!DOCTYPE html>
<html lang="vi">

<head>
    <!-- ========== Meta Tags ========== -->
    
    @include($_lib.'head')

</head>

<body>

    {!! $html->top->embeds !!}

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Header 
    ============================================= -->
    @include($_template.'header')   
    <!-- End Header -->

    @php
        // $md = isset($module)?$module:$__env->yieldContent('module', 'blog');
        // $sp = (isset($sidebar_pos)?$sidebar_pos:$__env->yieldContent('sidebar_pos', 'right')) != 'left' ? 'right' : 'left';
        // $sb = isset($sidebar)?$sidebar:$__env->yieldContent('sidebar', 'post');
        // $cl = isset($module_class)?$module_class:$__env->yieldContent('module_class', 'full-blog');
        $bc = isset($show_breadcrumb)?$show_breadcrumb:$__env->yieldContent('show_breadcrumb');
        // $pd = isset($main_padding)?$main_padding:$__env->yieldContent('main_padding', 'default');
        
    @endphp
    @if ($bc)
        @include($_template.'breadcrumbs')
    @endif
    
    @yield('content')

    <!-- Star Footer
    ============================================= -->

    @include($_template.'footer')     

    <!-- End Footer-->

    <!-- jQuery Frameworks
    ============================================= -->

    @include($_template.'js')
    {!! $html->bottom->embeds !!}
    

</body>

</html>