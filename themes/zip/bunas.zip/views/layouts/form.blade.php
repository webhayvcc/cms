<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from brandio.io/envato/iofrm/html/profile1.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 27 May 2020 16:55:05 GMT -->
<head>

    @include($_lib.'meta')
    
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/bootstrap.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/fontawesome-all.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/iofrm-style.css')}}">
    
    @yield('css')
    
    {!! $html->head->embeds !!}
</head>
<body>
    @yield('content')
<script src="{{theme_asset('forms/js/jquery.min.js')}}"></script>
<script src="{{theme_asset('forms/js/popper.min.js')}}"></script>
<script src="{{theme_asset('forms/js/bootstrap.min.js')}}"></script>
<script src="{{theme_asset('forms/js/main.js')}}"></script>
@yield('js')
</body>

</html>