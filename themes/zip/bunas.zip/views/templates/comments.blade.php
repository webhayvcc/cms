<?php
$commentList = (isset($comments) && is_countable($comments)) ? $comments : [];
$refname = isset($ref)?$ref:null;
$refid = isset($ref_id)?$ref_id:0;
$link = isset($url)?$url:null;
$t = count($commentList);
if($user = $helper->getCurrentAccount()){
    $name = $user->name;
    $email = $user->email;
}else{
    $name = null;
    $email = null;
}
?>
        <!-- Start Comments Form -->
        <div class="comments-area" id="comments">
            
            <div class="comments-title">
                <h4>
                    {{$t}} Bình luận
                </h4>
                @if ($t)
                <div class="comments-list">
                    @php
                        $render = function($factory, $comments, $level = 0){
                            $html = '';
                            if(count($comments)){
                                $html = '';
                                foreach ($comments as $key => $comment) {

                                    $avatar = ($comment->author_id && $author = get_model_data('user', $comment->author_id)) ? get_user_avatar($author->avatar) : asset('images/default/avatar.png');
                                    $html .= '
                                    <div class="commen-item '.($level>0?'reply reply-level-'.$level:'').'">
                                        <div class="avatar">
                                            <img src="'.$avatar.'" alt="Author">
                                        </div>
                                        <div class="content">
                                            <div class="top">
                                                <h5>'.$comment->author_name.'</h5>
                                                <p><i class="fas fa-clock"></i> '.$comment->dateFormat('d / m / Y').'</p>
                                            </div>
                                            <p>'.$comment->htmlMessage().'</p>
                                            '.($level > 2 ? '': '<a href="javascript:void(0);" class=" btn-reply-comment" data-id="'.$comment->id.'" data-reply-for="'.htmlentities($comment->author_name).'"><i class="fa fa-reply"></i> Trả lời</a>').'
                                        </div>
                                        
                                    </div>'
                                    .(($comment->publishChildren && count($comment->publishChildren)) ? $factory($factory, $comment->publishChildren, $level+1) : '').''
                                    ;

                                    
                                }
                                
                                $html.='';
                            }
                            return $html;
                        };
                    @endphp
                    {!! $render($render, $comments) !!}
                
                </div>

                @endif
            </div>
            <div class="comments-form">
                <div class="title">
                    <h4>Để lại ý kiến</h4>
                </div>
                <form class="contact-comments {{parse_classname('comment-form')}}" method="POST" action="{{route('client.comments.post')}}" data-ajax-url="{{route('client.comments.ajax')}}">
                    @csrf
                    <input type="hidden" name="parent_id" id="comment-reply-id" >
                    <input type="hidden" name="ref" value="{{$refname}}">
                    <input type="hidden" name="ref_id" value="{{$refid}}">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Name -->
                                <input type="text" name="author_name"  class="form-control inp" value="{{old('author_name', $name)}}" placeholder="Tên *" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <!-- Email -->
                                <input type="email" name="author_email"  class="form-control inp" value="{{old('author_email', $email)}}" placeholder="Email *">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group comments crazy-message-content">
                                <!-- Comment -->
                                <textarea name="message" class="comment-message-content inp form-control " placeholder="Viết nội dung bình luận..." required>{{old('message')}}</textarea>
                            </div>
                            <div class="form-group full-width submit">
                                <button type="submit">
                                    Gửi
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- End Comments Form -->