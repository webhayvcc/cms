@php
    $footer  = $options->theme->footer;
@endphp

    <footer class="bg-dark default-padding text-light">
        <div class="container">
            <div class="row">
                {!! $html->footer->components !!}
                

                <div class="footer-bottom text-center">
                    <div class="col-md-12 text-center">
                        <p>
                            @if ($footer->copyright)
                                {!! $footer->copyright !!}
                            @else
                                
                            @endif
                            Copyright &copy; {{date('Y')}} All right reserved
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </footer>