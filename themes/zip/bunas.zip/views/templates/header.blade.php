@php
    $headerStyle = isset($header_style)?$header_style:$__env->yieldContent('header_style', $helper->getWebData('header_style'));
    $style = 'attr-border navbar-sticky bootsnav';
    if($headerStyle == '2'){
        $style = 'navbar-fixed navbar-transparent white bootsnav';
    }

    $header = $options->theme->header;
@endphp

    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default {{$style}}">

            <!-- Start Top Search -->
            <div class="container">
                <div class="row">
                    <div class="top-search">
                        <div class="input-group">
                            <form action="{{route('client.search')}}" method="GET">
                                <input type="text" name="s" class="form-control" placeholder="Tìm kiếm">
                                <button type="submit">
                                    <i class="fas fa-search"></i>
                                </button>  
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="{{route('home')}}">
                        @if ($headerStyle == '2')
                            <img src="{{$header->logo_light($header->logo($siteinfo->logo(theme_asset('img/logo.png'))))}}" class="logo logo-display" alt="{{$siteinfo->site_name}}">
                            <img src="{{$header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" class="logo logo-scrolled" alt="{{$siteinfo->site_name}}">
                        @else
                            <img src="{{$header->logo($siteinfo->logo(theme_asset('img/logo.png')))}}" class="logo" alt="{{$siteinfo->site_name}}">
                        @endif
                        
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    
                    {!! bunas_primary_menu([
                        'class' => 'nav navbar-nav navbar-right',
                        'data-in'=>"#",
                        'data-out'=>"#"
                    ]) !!}
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>

