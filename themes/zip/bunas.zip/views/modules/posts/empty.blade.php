@php
    $title = $dynamic->name;
    $sub_title = "Mới nhất";
    if(isset($category) && $category){
        $sub_title = $category->name;
        if($category->parent_id && $parent = $category->getParent()){
            $title = $parent->name;
        }
    }
@endphp

@extends($_layout.'sidebar',[
    'page_title' => $title,
    'show_breadcrumb' =>  1
])
@include($_lib.'register-meta')
@section('page_title', $title)
@section('content')
    <div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
@endsection