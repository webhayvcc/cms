@php
    $title = $dynamic->name;
    $sub_title = "Mới nhất";
    if(isset($category) && $category){
        $sub_title = $category->name;
        if($category->parent_id && $parent = $category->getParent()){
            $title = $parent->name;
        }
    }
@endphp

@extends($_layout.'sidebar',[
    'page_title' => $title,
    'show_breadcrumb' =>  1
])
@include($_lib.'register-meta')
@section('page_title', $title)
@section('content')

@if (count($posts))
   @foreach ($posts as $post)
       
        <!-- Single Item -->
        <div class="single-item item">
            <div class="thumb">
                <a href="{{$url = $post->getViewUrl()}}"><img src="{{$post->getImage('800x300')}}" alt="{{$post->title}}"></a>
                @if(count($post->tags))
                    <div class="tags">
                        @foreach ($post->tags as $tag)
                            <a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'':','}}
                        @endforeach
                    </div>
                @endif
            </div>
            <div class="info">
                <div class="meta">
                    <ul>
                        <li>{{$post->dateFormat('d/m/Y')}}</li>
                        {{-- @if ($post->comment_count) --}}
                        <li><a href="{{$url}}#comments"><i class="fas fa-comments"></i> {{$post->comment_count}} Bình luận</a></li>    
                        {{-- @endif --}}
                        
                    </ul>
                </div>
                <div class="title">
                    <h4>
                        <a href="{{$url}}">{{$post->title}} </a>
                    </h4>
                </div>
                
                <p>
                    {{$post->getShortDesc(120)}}
                </p>
                <a class="btn btn-theme border btn-sm" href="{{$url}}">Xem thêm</a>
            </div>
        </div>
        <!-- End Single Item --> 

    @endforeach

    {{$posts->links($_template.'pagination')}}
@else
<div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
@endif

@endsection