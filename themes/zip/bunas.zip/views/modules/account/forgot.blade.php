@extends($_layout.'master',[
    'page_title' => 'Quên mật khẩu', 
    'show_breadcrumb' =>  1
])
@section('title', 'Đăng nhập')

@section('content')


<div class="blog-area default-padding">
    <div class="container">
        <div class="max-500" style="margin: 0 auto;">
            <form method="POST" action="{{route('client.account.post-forgot')}}" class="{{parse_classname('forgot-form')}}" >
                @if ($next = old('next', $request->next))
                    <input type="hidden" name="next" value="{{$next}}">
                @endif
                @csrf
            
                <div class="ps-form__content">
                    <h5>Đặt lại mật khẩu</h5>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Nhập Email của bạn">
                    </div>
                    @if ($error = session('error'))
                        <div class="alert alert-danger text-center">
                            {{$error}}
                        </div>
                    @endif
                    <div class="form-group submtit">
                        <button class="ps-btn ps-btn--fullwidth">Gửi yêu cầu</button>
                    </div>
                </div>
                
                <div class="ps-form__footer">
                    <p>
                        <a href="{{route('client.account.login')}}">Đăng nhập</a>
                        | 
                        <a href="{{route('client.account.register')}}">Đăng ký</a>
                    </p>
                    
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

