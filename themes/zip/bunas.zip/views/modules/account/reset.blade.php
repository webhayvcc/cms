@extends($_layout.'master',[
    'page_title' => 'Tạo mật khẩu mới', 
    'show_breadcrumb' =>  1
])
@section('title', 'Tạo mật khẩu mới')
@section('page_type', 'my-account')

@section('content')


<div class="blog-area default-padding">
    <div class="container">
        <div class="max-500" style="margin: 0 auto;">
            <form method="POST" action="{{route('client.account.password.reset')}}" class="{{parse_classname('reset-form')}}" >
                @if ($next = old('next', $request->next))
                    <input type="hidden" name="next" value="{{$next}}">
                @endif
                @csrf
                <input type="hidden" name="token" value="{{old('token', $token)}}">
            
                <div class="ps-form__content">
                    <h5>Tạo mật khẩu mới</h5>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Mật khẩu mới">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password_confirmation" placeholder="Nhập lại mật khẩu">
                    </div>
                    
                    @if ($error = $errors->first('password')??session('error'))
                        <div class="alert alert-danger text-center">
                            {{$error}}
                        </div>
                    @endif
                    <div class="form-group submtit">
                        <button class="ps-btn ps-btn--fullwidth">Tạo mật khẩu</button>
                    </div>
                </div>
                
                <div class="ps-form__footer">
                    <p>
                        <a href="{{route('client.account.login')}}">Đăng nhập</a>
                        | 
                        <a href="{{route('client.account.register')}}">Đăng ký</a>
                    </p>
                    
                </div>
            </form>
        </div>
    </div>
</div>



@endsection