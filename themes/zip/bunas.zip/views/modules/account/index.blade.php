@extends($_layout.'single')
@section('title', $account->formConfig->title)
@include($_lib.'register-meta')

@section('page_after')
<div class="ps-vendor-dashboard pro pt-60">
    <div class="container">
        <div class="row">
            <div class="col-sm-4 col-md-3">
                <aside class="widget widget_shop">
                    <ul class="ps-list--categories">
                        @foreach ($account->settings as $sk => $item)
                            <li><a class="{{$account->tab == $sk ? "active":""}}" href="{{route('client.account.settings', ['tab' => $item->slug])}}">{{$item->title}}</a></li>
                        @endforeach
                        <li><a class="" href="{{route('client.orders.manager')}}">Quản lý đơn hàng</a></li>
                        <li><a class="" href="{{route('client.account.logout')}}">Thoát</a></li>
                    </ul>
            </div>
            <div class="col-sm-8 col-md-9">
                <figure class="ps-block--vendor-status">
                    <figcaption>{{$account->formConfig->title}}</figcaption>
                    <form method="POST" action="{{route('client.account.settings', ['tab' => $account->formConfig->slug])}}" class="form">
                        @csrf
                        @if ($message = session('message'))
                            <div class="alert alert-success mb-3">
                                {{$message}}
                            </div>
                        @elseif($error = session('error'))
                            <div class="alert alert-danger mb-3">
                                {{$error}}
                            </div>
                        @endif
                        @if ($form = $account->form)
                            <?php
                                $form->map('addClass', 'form-control');
                            ?>
                            @foreach ($form as $input)
                                <div class="form-group">
                                    <label for="{{$input->id}}" class="form__label">{{$input->label}}</label>
                                    {!!$input!!}
                                    @if ($input->error)
                                        <div class="error has-error text-danger">{{$input->error}}</div>
                                    @endif
                            
                                </div> 
                            
                            @endforeach
                        @endif
                        
                        <div class="form-group row">
                            <button type="submit" class="ps-btn">Cập nhật</button>
                            
                        </div>
                    </form>
                </figure>
            </div>
        </div>
    </div>
</div>
@endsection