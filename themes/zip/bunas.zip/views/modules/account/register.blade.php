@extends($_layout.'form')
@section('title', 'Đăng ký tài khoản')
{{-- @section('page_type', 'my-account') --}}
@section('css')
<link rel="stylesheet" type="text/css" href="{{theme_asset('forms/css/iofrm-theme15.css')}}">
<style>
    .form-content .form-items {
        max-width: 600px;
    
    }
    .has-error.error{
        position: relative;
        top: -14px;
    }
</style>
@endsection
@section('content')
@php
    $header = $options->theme->header;
    $forms = $options->theme->forms;

    $logo = $forms->logo_light?$forms->logo_light:(
        $forms->logo?$forms->logo:(
            $header->logo_light?$header->logo_light:(
                $header->logo?$header->logo:(
                    $siteinfo->logo?$siteinfo->logo:(
                        theme_asset('img/logo-white.png')
                    )
                )
            )
        )
    );
@endphp
<div class="form-body on-top-mobile">
    <div class="website-logo">
        <a href="{{route('home')}}">
            <div class="logo">
                <img src="{{$logo}}" class="logo logo-size" alt="{{$siteinfo->site_name}}">
            </div>
        </a>
    </div>
    <div class="row">
        <div class="img-holder">
            <div class="bg"></div>
            <div class="info-holder">
                <h3>{{$forms->register_title}}</h3>
                <p>{!!$forms->register_description!!}</p>
            </div>
        </div>
        <div class="form-holder">
            <div class="form-content">
                <div class="form-items">
                    <h3 class="form-title">Đăng ký tài khoản</h3>
                    <form class="{{parse_classname('register-form')}}" action="{{route('client.account.post-register')}}" method="POST">
                        @if ($next = old('next', $request->next))
                            <input type="hidden" name="next" value="{{$next}}">
                        @endif
                        @php
                            $request = request();
                            $form = $html->getRegisterForm([
                                'class' => 'form-control'
                            ]);
                        @endphp
                        @csrf
                        
                        <div class="form-group">
                            <label>Thông tin cá nhân</label>
                            <div class="form-row">
                                <div class="col-sm-6">
                                    {!! $form->last_name !!}
                                    @if ($form->last_name->error)
                                        <div class="has-error error text-danger">{{$form->last_name->error}}</div>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    {!! $form->first_name !!}
                                    @if ($form->first_name->error)
                                        <div class="has-error error text-danger">{{$form->first_name->error}}</div>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    {!! $form->email !!}
                                    @if ($form->email->error)
                                        <div class="has-error error text-danger">{{$form->email->error}}</div>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    {!! $form->phone_number !!}
                                    @if ($form->phone_number->error)
                                        <div class="has-error error text-danger">{{$form->phone_number->error}}</div>
                                    @endif
                                </div>
                                <div class="col-12">
                                    {!! $form->username !!}
                                    @if ($form->username->error)
                                        <div class="has-error error text-danger">{{$form->username->error}}</div>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    {!! $form->password !!}
                                    @if ($form->password->error)
                                        <div class="has-error error text-danger">{{$form->password->error}}</div>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    {!! $form->password_confirmation !!}
                                    @if ($form->password_confirmation->error)
                                        <div class="has-error error text-danger">{{$form->password_confirmation->error}}</div>
                                    @endif
                                </div>
                            </div>
                            
                        </div>
                        
                        <div class="form-group">
                            <label>Thông tin gói dịch vụ</label>
                            @php
                                $webType = $form->web_type;
                                $webTypeData = $webType->getInputData();
                                $def =  old('web_type', $request->package?$request->package:$webType->defVal());
                            @endphp
                            <div class="custom-options">
                                @foreach ($webTypeData as $value => $label)
                                    @if (!$def && $loop->first)
                                        @php
                                            $def = $value;
                                        @endphp
                                    @endif
                                    <input type="radio" name="web_type" id="web-type-{{$value}}" @if($value == $def) checked @endif><label for="web-type-{{$value}}">{{$label}}</label>
                                @endforeach
                                
                            </div>
                            
                            @if ($form->web_type->error)
                                <div class="has-error error text-danger">{{$form->web_type->error}}</div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label>Tên miền</label>
                            <div class="input-group">
                                {!! $form->subdomain !!}
                                <div class="input-group-append">
                                    {!! $form->domain !!}
                                </div>
                            </div>
                            
                        </div>
                        @if ($form->subdomain->error)
                            <div class="has-error error text-danger">{{$form->subdomain->error}}</div>
                        @endif
                        <div class="form-group">
                            <label>Tên miền của bạn (nếu có)</label>
                            {!! $form->alias_domain !!}
                            @if ($form->alias_domain->error)
                                <div class="has-error error text-danger">{{$form->alias_domain->error}}</div>
                            @endif
                        </div>

                        <div class="row top-padding">
                            <div class="col-12 col-sm-9">
                                <input type="checkbox" id="agree" required><label for="agree">Tôi đồng ý với <a href="{{$forms->register_terms_link('#')}}">Các điều khoản</a> của {{$siteinfo->site_name('Web 1-0-2')}}</label>
                                @if ($form->agree->error)
                                    <div class="has-error error text-danger">{{$form->agree->error}}</div>
                                @endif
                            </div>
                            <div class="col-12 col-sm-3">
                                <div class="form-button text-right">
                                    <button id="submit" type="submit" class="ibtn less-padding">Đăng ký</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>




@endsection

@section('js')
    <script>
        $('.crazy-register-form').submit(function(e){
            

            if($(this).prop('submitted')) {
                e.preventDefault();
                return false;
            }

            $(this).prop('submitted', true);
            var submit = $(this).find('[type="submit"]');
            submit.html("Đang xử lý");
            submit.prop("disabled", true);
        });
    </script>
@endsection

@section('old')
    

<div class="ps-my-account blog-area default-padding">
    <div class="container">
        <div class="ps-form--account ps-tab-root">
            
<form class="{{parse_classname('register-form')}} comments-form" action="{{route('client.account.post-register')}}" method="POST">
    <div class="ps-form__content">
        
        @if ($form && $inputs = $form->inputs())
            @foreach ($inputs as $input)
            @php
                if($a = $request->get($input->name)){
                    if(!$input->value && !old($input->name))  $input->value = $a;
                }
            @endphp
            @if ($loop->index%2==0  || $loop->first)
            <div class="row">
            @endif
            <div class="col-6 col-sm-6 col-xs-12">
                <div class="form-group">
                    <label for="{{$input->id}}">{{$input->label}}</label>
                    {!! $input !!}
                    @if ($input->error)
                    <div class="has-error error text-danger">{{$input->error}}</div>
                    @endif
                </div>
            </div>
            @if ($loop->index%2==1||$loop->last)
                
            </div>
            @endif
            @endforeach
        @endif
        <div class="form-group submtit text-center">
            <button  type="submit" name="submit" id="submit">Đăng ký</button>
        </div>
    </div>

</form>

        </div>
    </div>
</div>


@endsection