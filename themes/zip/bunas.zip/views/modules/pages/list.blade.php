
@extends($_layout.'sidebar',[
    'show_breadcrumb' =>  2
])
@include($_lib.'register-meta')
@section('content')

<div class="page-title">
    <h2>{{$page_title}}</h2>
</div>

@if (count($pages))
   @foreach ($pages as $page)
       
        <!-- Single Item -->
        <div class="single-item item">
            <div class="info">
                <div class="title">
                    <h4>
                        <a href="{{$url}}">{{$page->title}} </a>
                    </h4>
                </div>
                
                <p>
                    {{$page->getShortDesc(120)}}
                </p>
                <a class="btn btn-theme border btn-sm" href="{{$url}}">Xem thêm</a>
            </div>
        </div>
        <!-- End Single Item --> 

    @endforeach

    {{$pages->links($_template.'pagination')}}
@else
<div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
@endif

@endsection