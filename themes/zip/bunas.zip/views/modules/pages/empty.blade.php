@extends($_layout.'sidebar',[
    'show_breadcrumb' =>  2
])
@include($_lib.'register-meta')
@section('page_title', $title)
@section('content')
    <div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
@endsection