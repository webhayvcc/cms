@extends($_layout.'sidebar',[
    'page_title' => $page_title,
    'show_breadcrumb' =>  1,
    'breadcrumb_type' => 2,
    'sidebar' => 'project'
])
@include($_lib.'register-meta')
@section('page_title', $page_title)
@section('content')

<div class="page-title">
    <h2>{{$page_title}}</h2>
</div>

@if (count($projects))
                    
@foreach ($projects as $project)
    @if ($loop->first || $loop->index % 2 == 0)
        
        <div class="row">
    @endif

    <!-- Single Item -->
    <div class="col-sm-6 col-5 col-xs-12 single-item">
        
        <div class="item">
            <div class="thumb">
                <a href="{{$url = $project->getViewUrl()}}"><img src="{{$project->getImage('social')}}" alt="{{$project->title}}"></a>
                @if($project->category)
                <div class="tags">
                    <a href="{{$project->category->getViewUrl()}}">{{$project->category->name}}</a>
                </div>
                @endif
            </div>
            <div class="info">
                {{-- <div class="meta">
                    <ul>
                        <li>{{$project->dateFormat('d/m/Y')}}</li>
                        <li><a href="{{$url}}#comments"><i class="fas fa-comments"></i> {{$project->comment_count}} Bình luận</a></li>    
                        
                        
                    </ul>
                </div> --}}
                <div class="title">
                    <h4>
                        <a href="{{$url}}">{{$project->title}} </a>
                    </h4>
                </div>
                
                <p>
                    {{$project->getShortDesc(100)}}
                </p>
                <a class="btn btn-theme border btn-sm" href="{{$url}}">Xem thêm</a>
            </div>
        </div>
    </div>
    <!-- End Single Item -->
    @if ($loop->last || $loop->index % 2 == 1)
         </div>
    @endif
@endforeach

{{$projects->links($_template.'pagination')}}
@else
<div class="alert alert-warning text-center mt-4 mb-4">Không có kết quả phù hợp</div>
@endif

@endsection