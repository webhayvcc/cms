@php
    $title = $article->title;
    $next = $article->next();
    $previous = $article->previous();
    $url = $article->getViewUrl();
    $category = $article->getCategory();
@endphp

@extends($_layout.'sidebar',[
    'page_title' => $title,
    'show_breadcrumb' =>  1,
    'breadcrumb_type' => 2,
    'sidebar' => 'project',

])
@include($_lib.'register-meta')
@section('page_title', $title)
@section('content')
<div class="item">

    <!-- Start Post Thumb -->
    <div class="thumb">
        <a href="{{$url = $article->getViewUrl()}}"><img src="{{$article->getImage('800x300')}}" alt="{{$article->title}}"></a>
        
        @if ($article->category && $tree = $article->category->getTree())
            <div class="tags">
                @foreach ($tree as $cate)
                <a href="{{$cate->getViewUrl()}}">{{$cate->name}}</a>
                @endforeach                                                
            </div>
        @endif
    </div>
    <!-- Start Post Thumb -->

    <div class="info">
        <div class="meta">
            <ul>
                <li>{{$article->dateFormat('d/m/Y')}}</li>
                {{-- @if ($article->comment_count) --}}
                <li><a href="{{$url}}#comments"><i class="fas fa-comments"></i> {{$article->comment_count}} Bình luận</a></li>    
                {{-- @endif --}}
                
            </ul>
        </div>
        <div class="title">
            <h4>
                <a href="{{$url}}">{{$article->title}} </a>
            </h4>
        </div>
        <div class="post-content">
            {!! $article->content !!}
        </div>
        
        @if ($next || $previous)

        <!-- Start Post Pagination -->
        <div class="post-pagi-area">
            @if ($previous)
            <a href="{{$previous->getViewUrl()}}"><i class="fas fa-angle-double-left"></i> Trước</a>
            @endif

            @if ($next)
                <a href="{{$article->getViewUrl()}}">Sau <i class="fas fa-angle-double-right"></i></a>
            @endif
        
        </div>
        <!-- End Post Pagination -->
        @endif

        <!-- Start Post Tag s-->
        <div class="post-tags share">
            @if(count($article->tags))
                <div class="tags">
                    <span>Tags: </span>
                    @foreach ($article->tags as $tag)
                        <a href="{{route('client.search', ['s' => $tag->keyword])}}">{{$tag->name}}</a>{{$loop->last?'': ', '}}
                    @endforeach
                </div>
            @endif
        </div>
        <!-- End Post Tags -->

        @include($_template.'comments',[
            'comments' => $article->publishComments,
            'ref' => 'project',
            'ref_id' => $article->id,
            'url' => $article->getViewUrl()
        ])

    </div>
</div>
@endsection